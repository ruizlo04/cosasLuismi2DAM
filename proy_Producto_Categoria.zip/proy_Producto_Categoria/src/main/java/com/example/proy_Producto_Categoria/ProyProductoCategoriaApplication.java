package com.example.proy_Producto_Categoria;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ProyProductoCategoriaApplication {

	public static void main(String[] args) {
		SpringApplication.run(ProyProductoCategoriaApplication.class, args);
	}

}
