package com.example.proy_Producto_Categoria;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ProyProductoCategoriaApplicationTests {

	@Test
	void contextLoads() {
	}

}
