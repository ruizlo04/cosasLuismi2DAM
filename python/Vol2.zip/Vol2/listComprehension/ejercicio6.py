lista_a = [1, 2, 3, 4]
lista_b = [2, 3, 4, 5]
comunes = [num for num in lista_a if num in lista_b]
print(comunes)