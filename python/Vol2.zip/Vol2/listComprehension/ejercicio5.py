lista = ["hi", 4, 8.99, "apple", ("t,b", "n")]
tuplas = [(i, v) for i, v in enumerate(lista)]
print(tuplas)