numbers = range(20)
par_impar = ["par" if num % 2 == 0 else "impar" for num in numbers]
print(par_impar)