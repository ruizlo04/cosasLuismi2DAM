for num in range(1, 1001): 
    if "3" in str(num): 
        print(num) 
