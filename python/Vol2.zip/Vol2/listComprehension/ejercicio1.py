for num in range(1, 1001):  
    if num % 7 == 0:  
        print(num) 
