cadena = "que dise mi loco"
espacios = cadena.count(" ")  
print("Número de espacios:", espacios)
